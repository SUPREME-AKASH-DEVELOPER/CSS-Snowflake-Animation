# 🎄 Christmas
- Responsive Christmas Landing page Design Using HTML CSS &amp; JavaScript.
- Contains animations when scrolling.
- Contains minimalist Preloader animation.
- Developed first for Desktop then for Mobile devices.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.
- Contains dark interface.





